<?php
// Start the session
session_start();

if( isset($_SESSION["username"])) {
    unset($_SESSION["username"]);
    header("Location: http://localhost/seatMap/controllers/login.php");
} else {
    header('Location: http://localhost/seatMap/index.php');
}