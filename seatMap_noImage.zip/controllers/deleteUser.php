<?php
// Start the session
session_start();
require_once('../models/Profile.php');

$user = new Profile();

/* Check authentication by session */
if( isset($_SESSION["username"])) {
    //$smarty->assign('username', $_SESSION["username"]);
}else {
    header('Location: http://localhost/seatMap/index.php');
}

if (isset($_POST['id']) && isset($_POST['path'])) {

    $id = $_POST['id'];
    $imagePath = $_POST['path'];
    //Delete image
    unlink ($imagePath);

    $success = $user->deleteUser($id);

    if($success) {
        $message = 'Profile is deleted successfully!';
    } else {
        $message = 'Can not delete this user!';
    }

    $_SESSION["success"] = $success;
    $_SESSION["message"] = $message;
    header('Location: http://localhost/seatMap/controllers/dashboard.php');
    var_dump($message);
}
