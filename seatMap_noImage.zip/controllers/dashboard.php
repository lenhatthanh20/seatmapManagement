<?php
session_start();

require_once('../libs/custom/smarty/smartyConfig.php');
require_once('../models/Profile.php');

$profile = new Profile();

global $_SESSION;
if( isset($_SESSION["username"])) {
    $smarty->assign('username', $_SESSION["username"]);
}else {
    header('Location: http://localhost/seatMap/index.php');
}

if( isset($_SESSION["success"]) && isset($_SESSION["message"]) ) {
    $smarty->assign('success', $_SESSION["success"]);
    $smarty->assign('message', $_SESSION["message"]);
    unset($_SESSION["success"]);
    unset($_SESSION["message"]);
}

/* List All Users */
$arrayAllProfile = $profile->listAllProfile();
//var_dump($arrayAllUser);
$smarty->assign('arrayAllProfile', $arrayAllProfile);

$smarty->display('dashboard.tpl');