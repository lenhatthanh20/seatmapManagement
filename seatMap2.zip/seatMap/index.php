<?php
//session_start();
//require_once('controllers/login.php');
//require_once('controllers/register.php');

echo "Homepage ";