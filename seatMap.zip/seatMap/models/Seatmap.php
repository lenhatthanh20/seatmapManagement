<?php
require_once ('databaseConfig.php');

$database = new Database();
$database->connect();

class Seatmap {
    public function addSeatmap($name, $type, $size, $path, $lastUpdate) {
        $sql = "INSERT INTO seatmap (name, type, path, size, lastUpdate) 
                            VALUES ('{$name}', '{$type}', '{$path}', '{$size}', '{$lastUpdate}')";
        $result = $GLOBALS['database']->databaseQuery($sql);
        if(isset($result)) {
            return true;
        } else {
            return false;
        }
    }

    public function listAllSeatmap() {
        $sql = "SELECT * FROM seatmap";
        $result = $GLOBALS['database']->databaseQuery($sql);
        $result = $GLOBALS['database']->databaseFetch($result);
        if($result) {
            return $result;
        } else {
            return false;
        }
    }

    public function selectUser($id) {

        $isIdValid = $this->checkValidId($id);
        if ($isIdValid !== true){
            return false;
        } else {
            $sql = "SELECT * FROM USER WHERE id='{$id}'";
            $result = $GLOBALS['database']->databaseQuery($sql);
            $result = $GLOBALS['database']->databaseFetch($result);
            if($result) {
                return $result;
            } else {
                return false;
            }
        }
    }

    public function updateUser($id, $username, $email, $picture) {

        $isIdValid = $this->checkValidId($id);
        if ($isIdValid !== true){
            return false;
        }

        $sql = "UPDATE user SET username='{$username}', email='{$email}', picture='{$picture}'
                WHERE id = '{$id}'";

        $result = $GLOBALS['database']->databaseQuery($sql);

        if($result){
            return true;
        } else {
            return false;
        }
    }

    public function deleteUser($id) {
        $isIdValid = $this->checkValidId($id);
        if ($isIdValid !== true){
            return false;
        } else {
            $sql = "DELETE FROM USER WHERE id = '{$id}'";
            $result = $GLOBALS['database']->databaseQuery($sql);
            if($result) {
                return true;
            } else {
                return false;
            }
        }
    }

    public function checkValidId($id) {
        $sql = "SELECT IF( EXISTS(
                            SELECT id
                            FROM USER
                            WHERE id = '{$id}'
                            LIMIT 1), 'exist', 'notexist')";
        $result = $GLOBALS['database']->databaseQuery($sql);
        $result = $GLOBALS['database']->databaseFetch($result);
        if($result[0][0] === 'exist') {
            return true;
        } else {
            return false;
        }
    }

    public function checkExistUsername($username) {
        $sql = "SELECT IF( EXISTS(
                            SELECT username
                            FROM user
                            WHERE username = '{$username}'
                            LIMIT 1), 'exist', 'notexist')";
        $result = $GLOBALS['database']->databaseQuery($sql);
        $result = $GLOBALS['database']->databaseFetch($result);
        if($result[0][0] === 'notexist') {
            return true;
        } else {
            return false;
        }
    }
}